<?php
$plugin_info = array();
$plugin_info['title'] = "오디오 플레이어";
$plugin_info['description'] = "오디오 플레이어";
$plugin_info['version'] = "1.0";
$plugin_info['author'] = "EXUS";
?>