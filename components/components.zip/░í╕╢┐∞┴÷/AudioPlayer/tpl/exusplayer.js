(function( window, document ) {
	function setElement(){
		window.video = document.getElementsByTagName('video')[0],
		window.videoControls = document.getElementById('controlBox'),	
		window.play = document.getElementById('play'),

		window.progressInterval,
		window.isVideoFullScreen = false,
		window.isEQOpen = false,
		
		window.videocontainer = document.getElementById("video_container"),
		window.lyrics = document.getElementById("lyrics"),
		window.lyricsextend = document.getElementById("lyricsextend"),
		window.eq = document.getElementById("eq"),
		window.title = document.getElementById("title"),
		window.timer = document.getElementById("time"),
		window.progressContainer = document.getElementById("progress"),
		window.progressHolder = document.getElementById("progress_box"),
		window.progressBar = document.getElementById("play_progress"),
		window.loadedBar = document.getElementById("play_loaded"),
		
		window.fullScreenToggleButton = document.getElementById("fullScreen"),
		
		window.ie = (function() {
			var undef,
				v = 3,
				div = document.createElement('div'),
				all = div.getElementsByTagName('i');
			
			while (
				div.innerHTML = '<!--[if gt IE ' + (++v) + ']><i></i><![endif]-->',
				all[0]
			);
			
			return v > 4 ? v : undef;
			
		}());
	}
	
	var videoPlayer = {
	
		init : function() {
			window.setElement();
			
			if ( ie < 9 ) return;
			
			var that = this;
			
			document.documentElement.className = 'js';
			
			window.video.removeAttribute('controls');
			window.video.addEventListener('loadeddata', this.initializeControls, false);

			window.fullScreenToggleButton.addEventListener("click", function(){
				isVideoFullScreen ? that.fullScreenOff() : that.fullScreenOn();
				setTimeout(function(){ rearrangeLyricsPosition();}, 500);
			}, true);
			
			this.videoScrubbing();
		},
		initializeControls : function() {
			videoPlayer.showHideControls();
		},
		showHideControls : function() {
			window.video.addEventListener('mouseover', function() {
				window.videoControls.style.opacity = 1;
				window.title.style.opacity = 1;
			}, false);
			
			window.video.addEventListener('mouseout', function(e) {
				window.videoControls.style.opacity = 0;
				window.title.style.opacity = 0;
			}, false);
			
			window.videoControls.addEventListener('mouseover', function() {
				window.videoControls.style.opacity = 1;
				window.title.style.opacity = 1;
			}, false);
			
			window.videoControls.addEventListener('mouseout', function() {
				window.videoControls.style.opacity = 0;
				window.title.style.opacity = 0;
			}, false);
		},
		fullScreenOn : function() {
			isVideoFullScreen = true;
			$('.lyrics_display').addClass('lyrics_focus');
			window.video.style.cssText = 'object-fit: contain;z-index:-1;max-height: 100%;image-rendering: -webkit-optimize-contrast;position: fixed; width:' + window.innerWidth + 'px; height: ' + window.innerHeight + 'px;';
			window.video.className = 'fullsizeVideo';
			window.videocontainer.className = 'fullsizeMode';
			window.videoControls.className = 'fs-control';
			window.fullScreenToggleButton.className = "fs-active control";
			document.addEventListener('keydown', this.checkKeyCode, false);
		},
		fullScreenOff : function() {
			$('.lyrics_display').removeClass('lyrics_focus');
			window.isVideoFullScreen = false;
			window.video.style.position = 'static';
			window.video.className = '';
			window.video.style.cssText = '';
			window.videocontainer.className = '';
			window.fullScreenToggleButton.className = "control";
			window.videoControls.className = '';
		},
		toggleLyricsExtend: function() {
			$(".lyrics_display_expand").toggle("slow", function() {});
		},
		toggleLyrics: function() {
			$(".lyrics_display").toggle("slow", function() {});
		},
		toggleEQ: function() {
			window.isEQOpen = (window.isEQOpen == true) ? true : false;
			$(".eq").toggle("slow", function() {});
		},
		handleButtonPresses : function() {
			window.video.addEventListener('click', this.playPause, false);
			window.play.addEventListener('click', this.playPause, false);
			window.lyrics.addEventListener('click', this.toggleLyrics, false);
			window.lyricsextend.addEventListener('click', this.toggleLyricsExtend, false);
			window.eq.addEventListener('click', this.toggleEQ, false);
			
			window.video.addEventListener('play', function() {
				window.play.title = 'Pause';
				window.play.innerHTML = '<span id="pauseButton"><i class="fa fa-pause" aria-hidden="true"></i></span>';
				videoPlayer.trackPlayProgress();				
			}, false);
			
			window.video.addEventListener('pause', function() {
				window.play.title = 'Play';
				window.play.innerHTML = '<i class="fa fa-play" aria-hidden="true"></i>';
				videoPlayer.stopTrackingPlayProgress();
			}, false);
			
			window.video.addEventListener('ended', function() {
				this.currentTime = 0;
				this.pause();
			}, false);
		},
		formatTime: function (seconds) {
			minutes = Math.floor(seconds / 60);
			minutes = (minutes >= 10) ? minutes : "0" + minutes;
			seconds = Math.floor(seconds % 60);
			seconds = (seconds >= 10) ? seconds : "0" + seconds;
			return minutes + ":" + seconds;
		},
		playPause: function() {
			if ( window.video.paused || window.video.ended ) {				
				if ( window.video.ended ) { 
					window.video.currentTime = 0; 
				}
				window.video.play();
			} else { 
				window.video.pause(); 
			}
		},
		trackPlayProgress : function(){
			(function progressTrack() {
				videoPlayer.updatePlayProgress();
				window.progressInterval = setTimeout(progressTrack, 50);
			 })();
		},
		updatePlayProgress : function(){
			window.timer.innerHTML = "<span style=color:red>" + this.formatTime(parseInt(window.video.currentTime)) + "</span> / " + this.formatTime(parseInt(window.video.duration));
			window.progressBar.style.width = ((window.video.currentTime / window.video.duration) * (window.progressHolder.offsetWidth)) + "px";
			
			var r = window.video.buffered;
			var total = window.video.duration;

			var start = r.start(0);
			var end = r.end(0);
			window.loadedBar.style.width = (end/total)*100 + "%";
		},
		stopTrackingPlayProgress : function(){
			clearTimeout(window.progressInterval);
		},
		videoScrubbing : function() {
			window.progressHolder.addEventListener("mousedown", function(){
				videoPlayer.stopTrackingPlayProgress();
				videoPlayer.playPause();
			
				document.onmousemove = function(e) {
					videoPlayer.setPlayProgress( e.pageX );
				}
				
				window.progressHolder.onmouseup = function(e) {
					document.onmouseup = null;
					document.onmousemove = null;
										
					window.video.play();
					videoPlayer.setPlayProgress( e.pageX );
					videoPlayer.trackPlayProgress();
				}
			}, true);
		},setPlayProgress : function( clickX ) {
			var newPercent = Math.max(0, Math.min(1, (clickX - this.findPosX(window.progressHolder)) / window.progressHolder.offsetWidth) );
			window.video.currentTime = newPercent * window.video.duration;
			window.progressBar.style.width = newPercent * (window.progressHolder.offsetWidth)  + "px";
		},findPosX : function(progressHolder) {
			var curleft = progressHolder.offsetLeft;
			while(progressHolder = progressHolder.offsetParent ) {
				curleft += progressHolder.offsetLeft;
			}
			return curleft;
		},checkKeyCode : function(e) {
			e = e || window.event;
			if ( (e.keyCode || e.which) === 27 ) videoPlayer.fullScreenOff();
		}
	};
	
	window.setElement = (function(){
		setElement();
	});
	
	window.initVideo = function initVideo(){
		$(document).ready(function() {
			videoPlayer.init();
		});
	}
})( this, document);