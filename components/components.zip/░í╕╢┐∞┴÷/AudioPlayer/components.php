<?php

class AudioPlayer{
	
	function transHTML($status, $args, $script){
		
		if($status !== 'before' || $script->object !== 'audio') return;
		
		$this->base = $args->base;
		$document_srl = (int)$this->base->get_params('srl');
		if(!$document_srl || $document_srl <= -1) return;
		
		$oFileModel = $this->base->getModel('files');
		$fileSequence = $oFileModel->getDocumentFileSequence($document_srl);
			
		$FileList = $oFileModel->getFileList($fileSequence);
		
		$oBoardModel = $this->base->getModel('music');
		$oDocument = $oBoardModel->getDocumentItems($document_srl);
		
		foreach($FileList as $key=>$val){
			if (maya::execute('@\@!jpg||png||gif||jpeg!', $val['files'], 'boolean')){
				$image_url = sprintf("%s%s%s/%s", __SUB, __FILE__ATTACH, $val['target'], $val['files']);
			}elseif (maya::execute('@\@!mp3||wav!', $val['files'], 'boolean')){
				$audio_url = sprintf("%s%s%s/%s", __SUB, __FILE__ATTACH, $val['target'], $val['files']);
			}elseif (maya::execute('@\@!mp4||avi!', $val['files'], 'boolean')){
				$audio_url = sprintf("%s%s%s/%s", __SUB, __FILE__ATTACH, $val['target'], $val['files']);
			}
		}
		
		if(!$image_url || !$audio_url) return;
		
		$this->base->addJS("/components/Audioplayer/tpl/lyrics.js","body");
		$this->base->addCSS("/components/Audioplayer/tpl/lyrics.css");
		
		$this->base->addJS("/components/Audioplayer/tpl/exusplayer.js","body");
		$this->base->addCSS("/components/Audioplayer/tpl/exusplayer.css");
		
		$this->base->set('title', $oDocument['title']);
		$this->base->set('lyricssrl', request::encodeBinaryNumberic($oDocument['srl']));
		$this->base->set('audio_url', $audio_url);
		$this->base->set('image_url', $image_url);
		
		$skin = __COMPONENTS."/AudioPlayer/tpl/player.php";
		
		ob_start();
					
		if(isset($skin)){
			if(file_exists($skin)){
				@include($skin);
			}else{
				if($required) die("invalid skin");
			}
		}
		
		$include = ob_get_clean();
		return $include;
	}
}
?>