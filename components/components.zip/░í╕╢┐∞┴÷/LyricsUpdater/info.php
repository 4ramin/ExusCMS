<?php
$plugin_info = array();
$plugin_info['title'] = "가사 업데이트";
$plugin_info['description'] = "가사 업데이트";
$plugin_info['version'] = "1.0";
$plugin_info['author'] = "EXUS";
?>