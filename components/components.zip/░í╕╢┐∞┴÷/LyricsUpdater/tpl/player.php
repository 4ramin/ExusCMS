<script>
$(document).ready(function() {
	request_lyrics('<?php echo $this->base->get('lyricssrl'); ?>');
});
</script>